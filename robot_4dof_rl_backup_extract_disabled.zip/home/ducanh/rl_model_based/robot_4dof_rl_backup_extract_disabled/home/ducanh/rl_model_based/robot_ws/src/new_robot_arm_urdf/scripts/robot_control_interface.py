#!/usr/bin/env python3
"""
Robot Control Interface for RL Training
Bridges between Python RL environment and Gazebo simulation via ROS
"""

import rospy
import numpy as np
from std_msgs.msg import Float64
from sensor_msgs.msg import JointState
from std_srvs.srv import Empty, EmptyResponse
from geometry_msgs.msg import Pose, Point, Quaternion
import tf.transformations as tf_trans
import threading
import time

class RobotControlInterface:
    def __init__(self):
        rospy.init_node('robot_control_interface', anonymous=True)
        
        # Robot parameters (matching Robot4DOFEnv)
        self.dof = 4
        self.joint_names = ['Joint_1', 'Joint_2', 'Joint_3', 'Joint_4']
        self.link_lengths = np.array([0.033399, 0.053, 0.063, 0.053])
        
        # State variables
        self.joint_positions = np.zeros(self.dof)
        self.joint_velocities = np.zeros(self.dof)
        self.joint_efforts = np.zeros(self.dof)
        self.state_lock = threading.Lock()
        
        # Publishers for joint position commands
        self.joint_pubs = []
        for i in range(self.dof):
            pub = rospy.Publisher(
                f'/joint{i+1}_position_controller/command', 
                Float64, 
                queue_size=1
            )
            self.joint_pubs.append(pub)
        
        # Subscriber for joint states
        self.joint_state_sub = rospy.Subscriber(
            '/joint_states', 
            JointState, 
            self.joint_state_callback
        )
        
        # Services for RL environment
        self.reset_srv = rospy.Service('/robot/reset', Empty, self.reset_callback)
        self.get_state_srv = rospy.Service('/robot/get_state', Empty, self.get_state_callback)
        
        # Publishers for RL interface
        self.state_pub = rospy.Publisher('/robot/state', JointState, queue_size=1)
        self.ee_pose_pub = rospy.Publisher('/robot/end_effector_pose', Pose, queue_size=1)
        
        # Subscribers for RL commands
        self.cmd_sub = rospy.Subscriber('/robot/joint_commands', JointState, self.joint_command_callback)
        
        rospy.loginfo("Robot Control Interface initialized")
        
    def joint_state_callback(self, msg):
        """Callback for joint state updates from Gazebo"""
        with self.state_lock:
            try:
                # Map joint states to our joint order
                for i, joint_name in enumerate(self.joint_names):
                    if joint_name in msg.name:
                        idx = msg.name.index(joint_name)
                        self.joint_positions[i] = msg.position[idx]
                        if len(msg.velocity) > idx:
                            self.joint_velocities[i] = msg.velocity[idx]
                        if len(msg.effort) > idx:
                            self.joint_efforts[i] = msg.effort[idx]
                
                # Publish state for RL environment
                self.publish_state()
                
            except Exception as e:
                rospy.logwarn(f"Error in joint state callback: {e}")
    
    def joint_command_callback(self, msg):
        """Callback for joint commands from RL environment"""
        try:
            # Map commands to joint controllers
            for i, joint_name in enumerate(self.joint_names):
                if i < len(msg.position):
                    # Clamp to joint limits
                    cmd = np.clip(msg.position[i], -np.pi, np.pi)
                    self.joint_pubs[i].publish(Float64(cmd))
                    
        except Exception as e:
            rospy.logwarn(f"Error in joint command callback: {e}")
    
    def publish_state(self):
        """Publish current robot state"""
        # Joint states
        state_msg = JointState()
        state_msg.header.stamp = rospy.Time.now()
        state_msg.name = self.joint_names
        state_msg.position = list(self.joint_positions)
        state_msg.velocity = list(self.joint_velocities)
        state_msg.effort = list(self.joint_efforts)
        self.state_pub.publish(state_msg)
        
        # End-effector pose
        ee_pos = self.forward_kinematics(self.joint_positions)
        pose_msg = Pose()
        pose_msg.position = Point(x=ee_pos[0], y=ee_pos[1], z=ee_pos[2])
        pose_msg.orientation = Quaternion(w=1.0)  # No orientation for now
        self.ee_pose_pub.publish(pose_msg)
    
    def forward_kinematics(self, joint_angles):
        """Compute forward kinematics (matching Robot4DOFEnv implementation)"""
        q1, q2, q3, q4 = joint_angles
        
        # Base rotation
        c1, s1 = np.cos(q1), np.sin(q1)
        
        # DH parameters for the arm
        x = (self.link_lengths[1] * np.cos(q2) + 
             self.link_lengths[2] * np.cos(q2 + q3) + 
             self.link_lengths[3] * np.cos(q2 + q3 + q4))
        
        # Apply base rotation
        ee_x = c1 * x
        ee_y = s1 * x
        ee_z = (self.link_lengths[0] + 
                self.link_lengths[1] * np.sin(q2) + 
                self.link_lengths[2] * np.sin(q2 + q3) + 
                self.link_lengths[3] * np.sin(q2 + q3 + q4))
        
        return np.array([ee_x, ee_y, ee_z])
    
    def reset_callback(self, req):
        """Service callback for resetting robot to initial pose"""
        try:
            # Reset to neutral pose
            reset_pose = [0.0, 0.2, -0.3, 0.1]
            
            for i, pos in enumerate(reset_pose):
                self.joint_pubs[i].publish(Float64(pos))
            
            # Wait for movement to complete
            rospy.sleep(1.0)
            
            rospy.loginfo("Robot reset completed")
            return EmptyResponse()
            
        except Exception as e:
            rospy.logerr(f"Error in reset callback: {e}")
            return EmptyResponse()
    
    def get_state_callback(self, req):
        """Service callback for getting current robot state"""
        with self.state_lock:
            self.publish_state()
        return EmptyResponse()
    
    def command_joints(self, joint_positions):
        """Direct method to command joint positions"""
        for i, pos in enumerate(joint_positions):
            if i < len(self.joint_pubs):
                self.joint_pubs[i].publish(Float64(pos))
    
    def get_current_state(self):
        """Get current robot state as numpy arrays"""
        with self.state_lock:
            return {
                'joint_positions': self.joint_positions.copy(),
                'joint_velocities': self.joint_velocities.copy(),
                'joint_efforts': self.joint_efforts.copy(),
                'end_effector_pos': self.forward_kinematics(self.joint_positions)
            }
    
    def run(self):
        """Main loop"""
        rate = rospy.Rate(100)  # 100 Hz
        
        while not rospy.is_shutdown():
            try:
                # Periodic state publishing
                if hasattr(self, 'joint_positions'):
                    self.publish_state()
                    
            except Exception as e:
                rospy.logwarn(f"Error in main loop: {e}")
                
            rate.sleep()

def main():
    try:
        interface = RobotControlInterface()
        interface.run()
        
    except rospy.ROSInterruptException:
        rospy.loginfo("Robot Control Interface shutting down")
    except Exception as e:
        rospy.logerr(f"Error in robot control interface: {e}")

if __name__ == '__main__':
    main()