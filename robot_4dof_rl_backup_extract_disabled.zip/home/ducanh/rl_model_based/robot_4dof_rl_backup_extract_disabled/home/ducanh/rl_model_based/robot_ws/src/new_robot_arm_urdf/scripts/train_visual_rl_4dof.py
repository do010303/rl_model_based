#!/usr/bin/env python3
"""
Complete Visual RL Training System for 4DOF Robot Arm in ROS Noetic
Integration of RL Environment + DDPG Algorithm + Visual Gazebo Training

This script provides the complete visual RL training pipeline:
1. Initialize 4DOF robot in Gazebo with visual environment
2. Setup DDPG agent for continuous control learning
3. Run training episodes with visual feedback
4. Log training progress and save models
5. Provide evaluation and testing capabilities

Key features:
- Visual training in Gazebo with robot movement and target sphere
- DDPG algorithm adapted for 4DOF robot arm
- Real-time training metrics and visualization
- Model saving/loading for training continuation
- Episode management with proper environment resets

Author: Adapted from David Valencia's ROS2 implementation for 4DOF ROS Noetic
"""

import rospy
import os
import sys
import time
import numpy as np
from datetime import datetime
from typing import Optional, Tuple, Dict, Any

# Add scripts directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import our custom modules
from main_rl_environment_noetic import RLEnvironmentNoetic
from ddpg_4dof_noetic import DDPGAgent, TrainingMetrics

# Gym-style action space for DDPG
class ActionSpace:
    """Gym-style action space for DDPG agent"""
    
    def __init__(self, low, high):
        self.low = np.array(low)
        self.high = np.array(high)
        self.shape = (len(low),)
    
    def sample(self):
        """Sample random action"""
        return np.random.uniform(self.low, self.high)


class VisualRLTraining:
    """
    Complete Visual RL Training System for 4DOF Robot
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the complete visual RL training system
        
        Args:
            config: Configuration dictionary for training parameters
        """
        rospy.loginfo("🚀 Initializing Complete Visual RL Training System...")
        
        # Default configuration
        self.config = {
            'max_episodes': 1000,
            'max_steps_per_episode': 200,
            'batch_size': 128,
            'learning_rate_actor': 1e-4,
            'learning_rate_critic': 1e-3,
            'gamma': 0.99,
            'tau': 1e-2,
            'memory_size': 50000,
            'noise_scale': 0.1,
            'goal_tolerance': 0.05,
            'save_interval': 100,  # Save models every N episodes
            'log_interval': 10,    # Log progress every N episodes
            'eval_interval': 50,   # Evaluate every N episodes
            'eval_episodes': 5,    # Number of evaluation episodes
        }
        
        # Update with user config
        if config:
            self.config.update(config)
            
        # Initialize components
        self.env = None
        self.agent = None
        self.metrics = TrainingMetrics()
        
        # Training state
        self.episode_count = 0
        self.total_steps = 0
        self.best_success_rate = 0.0
        
        # Setup paths for saving
        self.setup_save_paths()
        
    def setup_save_paths(self):
        """Setup directories for saving models and logs"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create base directory for this training run
        self.save_dir = f"/home/ducanh/rl_model_based/robot_ws/training_results/ddpg_4dof_{timestamp}"
        os.makedirs(self.save_dir, exist_ok=True)
        
        # Subdirectories
        self.models_dir = os.path.join(self.save_dir, "models")
        self.plots_dir = os.path.join(self.save_dir, "plots")
        self.logs_dir = os.path.join(self.save_dir, "logs")
        
        for directory in [self.models_dir, self.plots_dir, self.logs_dir]:
            os.makedirs(directory, exist_ok=True)
            
        rospy.loginfo(f"📁 Training results will be saved to: {self.save_dir}")
    
    def initialize_environment(self):
        """Initialize the visual RL environment"""
        rospy.loginfo("🌍 Initializing Visual RL Environment...")
        
        try:
            self.env = RLEnvironmentNoetic()
            rospy.sleep(2.0)  # Wait for environment to be ready
            
            # Wait for environment to be ready with timeout
            timeout = 30.0
            start_time = time.time()
            
            while not self.env.data_ready and (time.time() - start_time) < timeout:
                rospy.loginfo("⏳ Waiting for environment to be ready...")
                rospy.sleep(1.0)
            
            if not self.env.data_ready:
                raise Exception("Environment failed to initialize within timeout")
                
            rospy.loginfo("✅ Visual RL Environment initialized successfully!")
            return True
            
        except Exception as e:
            rospy.logerr(f"❌ Failed to initialize environment: {e}")
            return False
    
    def initialize_agent(self):
        """Initialize the DDPG agent"""
        rospy.loginfo("🤖 Initializing DDPG Agent...")
        
        try:
            # Get environment information
            action_info = self.env.get_action_space_info()
            obs_info = self.env.get_observation_space_info()
            
            rospy.loginfo(f"📊 State space: {obs_info}")
            rospy.loginfo(f"🎮 Action space: {action_info}")
            
            # Create gym-style action space
            action_space = ActionSpace(
                low=action_info['low'],
                high=action_info['high']
            )
            
            # Initialize DDPG agent
            self.agent = DDPGAgent(
                state_dim=obs_info['shape'][0],      # 10 for 4DOF (3+4+3)
                action_dim=action_info['shape'][0],  # 4 for 4DOF robot
                action_space=action_space,
                hidden_size=256,
                actor_learning_rate=self.config['learning_rate_actor'],
                critic_learning_rate=self.config['learning_rate_critic'],
                gamma=self.config['gamma'],
                tau=self.config['tau'],
                max_memory_size=self.config['memory_size']
            )
            
            rospy.loginfo("✅ DDPG Agent initialized successfully!")
            return True
            
        except Exception as e:
            rospy.logerr(f"❌ Failed to initialize agent: {e}")
            return False
    
    def run_training_episode(self, episode_num: int, evaluation_mode: bool = False) -> Tuple[float, int, bool, float]:
        """
        Run a single training episode
        
        Args:
            episode_num: Current episode number
            evaluation_mode: If True, run without exploration noise
            
        Returns:
            tuple: (total_reward, episode_length, success, final_distance)
        """
        # Reset environment
        if not self.env.reset_environment():
            rospy.logwarn(f"⚠️ Failed to reset environment for episode {episode_num}")
            return 0.0, 0, False, float('inf')
        
        # Reset agent noise for new episode
        if not evaluation_mode:
            self.agent.reset_noise()
        
        # Episode variables
        total_reward = 0.0
        episode_length = 0
        success = False
        
        # Get initial state
        state = self.env.get_state()
        if state is None:
            rospy.logwarn("⚠️ Could not get initial state")
            return 0.0, 0, False, float('inf')
        
        # Episode loop
        for step in range(self.config['max_steps_per_episode']):
            # Get action from agent
            noise_scale = 0.0 if evaluation_mode else self.config['noise_scale']
            action = self.agent.get_action(state, add_noise=not evaluation_mode, noise_scale=noise_scale)
            
            # Execute action in environment
            if not self.env.execute_action(action):
                rospy.logwarn(f"⚠️ Action execution failed at step {step}")
                break
            
            # Wait for action to complete and get new state
            rospy.sleep(0.1)  # Small delay for action completion
            next_state = self.env.get_state()
            
            if next_state is None:
                rospy.logwarn(f"⚠️ Could not get next state at step {step}")
                break
            
            # Calculate reward and check if done
            reward, done = self.env.calculate_reward()
            total_reward += reward
            episode_length += 1
            
            # Check for goal achievement
            if reward > 5.0:  # Goal achievement reward
                success = True
                
            # Store experience for training (not during evaluation)
            if not evaluation_mode:
                self.agent.add_experience(state, action, reward, next_state, done)
                
                # Perform learning step
                self.agent.step_training(self.config['batch_size'])
            
            # Update state
            state = next_state
            self.total_steps += 1
            
            # End episode if done
            if done:
                break
        
        # Get final distance to target
        final_distance = self.env.get_distance_to_goal()
        
        return total_reward, episode_length, success, final_distance
    
    def run_evaluation(self, num_episodes: int = 5) -> Tuple[float, float, float]:
        """
        Run evaluation episodes without exploration
        
        Args:
            num_episodes: Number of evaluation episodes
            
        Returns:
            tuple: (average_reward, success_rate, average_distance)
        """
        rospy.loginfo(f"🎯 Running evaluation for {num_episodes} episodes...")
        
        eval_rewards = []
        eval_successes = []
        eval_distances = []
        
        for i in range(num_episodes):
            reward, length, success, distance = self.run_training_episode(
                episode_num=f"eval_{i}", 
                evaluation_mode=True
            )
            
            eval_rewards.append(reward)
            eval_successes.append(success)
            eval_distances.append(distance)
            
            rospy.loginfo(f"   Eval {i+1}/{num_episodes}: Reward={reward:.2f}, Success={success}, Distance={distance:.4f}")
        
        avg_reward = np.mean(eval_rewards)
        success_rate = np.mean(eval_successes)
        avg_distance = np.mean(eval_distances)
        
        rospy.loginfo(f"📊 Evaluation Results:")
        rospy.loginfo(f"   Average Reward: {avg_reward:.2f}")
        rospy.loginfo(f"   Success Rate: {success_rate:.2%}")
        rospy.loginfo(f"   Average Final Distance: {avg_distance:.4f}m")
        
        return avg_reward, success_rate, avg_distance
    
    def save_models_and_progress(self, episode_num: int, force_save: bool = False):
        """Save models and training progress"""
        if episode_num % self.config['save_interval'] == 0 or force_save:
            # Save DDPG models
            model_prefix = os.path.join(self.models_dir, f"ddpg_4dof_ep_{episode_num}")
            self.agent.save_models(model_prefix)
            
            # Save training metrics
            metrics_file = os.path.join(self.logs_dir, f"training_metrics_ep_{episode_num}.pkl")
            self.metrics.save_metrics(metrics_file)
            
            # Generate and save training plots
            plot_file = os.path.join(self.plots_dir, f"training_progress_ep_{episode_num}.png")
            self.metrics.plot_training_progress(save_path=plot_file)
            
            rospy.loginfo(f"💾 Models and progress saved at episode {episode_num}")
    
    def run_training(self):
        """Run the complete training pipeline"""
        rospy.loginfo("🎓 Starting Visual RL Training Pipeline...")
        
        try:
            # Initialize components
            if not self.initialize_environment():
                return False
                
            if not self.initialize_agent():
                return False
            
            rospy.loginfo(f"🚀 Starting training for {self.config['max_episodes']} episodes...")
            
            # Training loop
            for episode in range(1, self.config['max_episodes'] + 1):
                self.episode_count = episode
                
                # Run training episode
                total_reward, episode_length, success, final_distance = self.run_training_episode(episode)
                
                # Update metrics
                self.metrics.add_episode(total_reward, episode_length, success, final_distance)
                
                # Log progress
                if episode % self.config['log_interval'] == 0:
                    recent_success_rate = self.metrics.get_recent_success_rate(window=50)
                    
                    rospy.loginfo(f"📈 Episode {episode}/{self.config['max_episodes']}:")
                    rospy.loginfo(f"   Reward: {total_reward:.2f}, Steps: {episode_length}")
                    rospy.loginfo(f"   Success: {success}, Distance: {final_distance:.4f}m")
                    rospy.loginfo(f"   Recent Success Rate: {recent_success_rate:.2%}")
                    rospy.loginfo(f"   Total Steps: {self.total_steps}")
                
                # Run evaluation
                if episode % self.config['eval_interval'] == 0:
                    avg_reward, success_rate, avg_distance = self.run_evaluation(self.config['eval_episodes'])
                    
                    # Save best model
                    if success_rate > self.best_success_rate:
                        self.best_success_rate = success_rate
                        best_model_prefix = os.path.join(self.models_dir, "ddpg_4dof_best")
                        self.agent.save_models(best_model_prefix)
                        rospy.loginfo(f"🏆 New best model saved! Success rate: {success_rate:.2%}")
                
                # Save progress
                self.save_models_and_progress(episode)
                
                # Check for early stopping (optional)
                if self.metrics.get_recent_success_rate(window=100) > 0.9:
                    rospy.loginfo("🎉 Training converged! Success rate > 90%")
                    break
                    
            # Final save
            self.save_models_and_progress(self.episode_count, force_save=True)
            
            rospy.loginfo("🎉 Training completed successfully!")
            return True
            
        except KeyboardInterrupt:
            rospy.loginfo("⏹️ Training interrupted by user")
            self.save_models_and_progress(self.episode_count, force_save=True)
            return False
        except Exception as e:
            rospy.logerr(f"❌ Training failed: {e}")
            return False
        finally:
            if self.env:
                self.env.shutdown()
    
    def load_and_continue_training(self, model_path_prefix: str, episode_start: int = 0):
        """Load existing models and continue training"""
        rospy.loginfo(f"📁 Loading models from: {model_path_prefix}")
        
        # Initialize components first
        if not self.initialize_environment() or not self.initialize_agent():
            return False
        
        # Load models
        self.agent.load_models(model_path_prefix)
        
        # Update episode counter
        self.episode_count = episode_start
        
        rospy.loginfo(f"🔄 Continuing training from episode {episode_start}")
        return self.run_training()


def main():
    """Main function to run visual RL training"""
    rospy.init_node('visual_rl_training_4dof', anonymous=True)
    
    try:
        rospy.loginfo("🤖 4DOF Robot Visual RL Training System")
        rospy.loginfo("=" * 50)
        
        # Training configuration
        config = {
            'max_episodes': 2000,
            'max_steps_per_episode': 200,
            'batch_size': 128,
            'learning_rate_actor': 1e-4,
            'learning_rate_critic': 1e-3,
            'gamma': 0.99,
            'tau': 1e-2,
            'memory_size': 100000,
            'noise_scale': 0.1,
            'goal_tolerance': 0.05,
            'save_interval': 50,
            'log_interval': 5,
            'eval_interval': 25,
            'eval_episodes': 3,
        }
        
        # Create and run training system
        trainer = VisualRLTraining(config)
        success = trainer.run_training()
        
        if success:
            rospy.loginfo("✅ Training completed successfully!")
        else:
            rospy.logerr("❌ Training failed or was interrupted")
            
    except KeyboardInterrupt:
        rospy.loginfo("⏹️ Training interrupted by user")
    except Exception as e:
        rospy.logerr(f"❌ Training system failed: {e}")
    
    rospy.loginfo("🏁 Visual RL Training System shutting down")


if __name__ == '__main__':
    main()