#!/usr/bin/env python3

"""
Simple robot movement test to debug error code -4.
Tests small incremental movements from the home position.
"""

import sys
sys.path.insert(0, '/home/ducanh/rl_model_based/robot_ws/src/new_robot_arm_urdf/scripts')

import rospy
import numpy as np
from main_rl_environment_noetic import RLEnvironmentNoetic

def test_simple_movement():
    """Test very simple robot movements to debug error code -4."""
    print("Testing simple robot movements...")
    try:
        # Initialize ROS node
        rospy.init_node('simple_movement_test', anonymous=True)
        print("✓ ROS node initialized")

        # Create environment
        env = RLEnvironmentNoetic()
        print("✓ Environment created")

        # Wait for initialization
        print("Waiting for environment to initialize...")
        rospy.sleep(3)

        # Reset environment
        print("Resetting environment...")
        success = env.reset_environment()
        print(f"✓ Environment reset successful: {success}")

        # Print joint limits for reference
        try:
            urdf_limits = env.robot_joint_limits if hasattr(env, 'robot_joint_limits') else None
            if urdf_limits:
                print("Joint limits (radian):")
                for i, lim in enumerate(urdf_limits):
                    print(f"  Joint {i+1}: [{lim[0]}, {lim[1]}]")
            else:
                print("(Could not read joint limits from environment)")
        except Exception:
            print("(Error reading joint limits)")

        print("\nTest nhập góc thủ công cho robot (Ctrl+C để thoát)...")
        while True:
            movement = get_user_joint_angles()
            print(f"\n--- Test Movement: {movement} ---")

            action_result = env.execute_action(movement)
            if not action_result:
                print("[WARN] ❌ Action server reported failure (error code -4 or similar). This does NOT mean the robot won't reach the target—waiting for robot to settle...")

            # Wait for robot to settle: position within tolerance AND velocity below threshold
            reached = wait_until_reached(env, movement, tol=0.1, timeout=8, vel_thresh=0.01)
            # Only print joint positions after robot has settled
            state = env.get_state()
            if state is not None:
                joints = np.array(state)[3:7]
                print(f"Final joint positions after movement: {joints}")
                if np.allclose(joints, movement, atol=0.1):
                    print("✅ Đạt trong tolerance 0.1 radian!")
                    print("✅ Movement successful! Robot reached the target (regardless of action server result).")
                else:
                    print("⚠️ Không đạt tolerance 0.1 radian!")
                    print("❌ Movement failed or did not reach target within tolerance.")
            else:
                print("Không lấy được trạng thái khớp!")

        print("\n✓ Simple movement test completed!")
        
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def get_user_joint_angles():
    print("Nhập 4 góc khớp (đơn vị radian, cách nhau bởi dấu cách):")
    while True:
        try:
            angles = input("Joint angles (ví dụ: 0.1 0 0 0): ").strip().split()
            if len(angles) != 4:
                print("Vui lòng nhập đúng 4 giá trị!")
                continue
            angles = [float(a) for a in angles]
            return np.array(angles)
        except Exception:
            print("Giá trị không hợp lệ, thử lại!")

def wait_until_reached(env, target, tol=0.1, timeout=10, vel_thresh=0.01):
    import time
    start = time.time()
    while time.time() - start < timeout:
        state = env.get_state()
        if state is not None:
            joints = np.array(state)[3:7]
            vels = np.array(state)[7:11] if len(state) >= 11 else np.zeros(4)
            pos_ok = np.allclose(joints, target, atol=tol)
            vel_ok = np.all(np.abs(vels) < vel_thresh)
            if pos_ok and vel_ok:
                time.sleep(0.2)
                return True
        time.sleep(0.1)
    return False

def wait_for_trajectory_and_check(env, target, tol=0.1, timeout=10):
    import time
    start = time.time()
    while time.time() - start < timeout:
        state = env.get_state()
        if state is not None:
            joints = np.array(state)[3:7]
            if np.allclose(joints, target, atol=tol):
                break
        time.sleep(0.1)
    # Always print current joint positions after waiting
    state = env.get_state()
    if state is not None:
        print(f"Current joint positions: {np.array(state)[3:7]}")
    else:
        print("Không lấy được trạng thái khớp!")

if __name__ == '__main__':
    success = test_simple_movement()
    sys.exit(0 if success else 1)