# Visual RL Training System for 4DOF Robot Arm - ROS Noetic

Complete visual reinforcement learning training system adapted from the ROS2 `robotic_arm_environment` for 4DOF robot arm in ROS Noetic.

## 🎯 System Overview

This system provides **complete visual RL training** with:

### **Core Components**
- **4DOF Robot Arm**: Your existing robot with trajectory control
- **Target Sphere**: Visual red sphere target that moves randomly in workspace  
- **RL Environment**: Complete state management and reward calculation
- **DDPG Algorithm**: Deep Deterministic Policy Gradient for continuous control
- **Visual Integration**: Real-time Gazebo simulation with robot learning

### **Key Features Adapted from ROS2 Version**
✅ **6DOF → 4DOF**: Action and state spaces adapted for your robot  
✅ **ROS2 → ROS Noetic**: Complete ROS1 architecture migration  
✅ **Visual Training**: Robot learns by watching and moving in Gazebo  
✅ **Target Manipulation**: Sphere moves to random positions for training  
✅ **Continuous Learning**: DDPG algorithm with experience replay  
✅ **Training Metrics**: Real-time logging and progress visualization  

## 📁 File Structure

```
robot_ws/src/new_robot_arm_urdf/
├── scripts/
│   ├── main_rl_environment_noetic.py     # Main RL environment (adapted from ROS2)
│   ├── ddpg_4dof_noetic.py               # DDPG algorithm for 4DOF robot
│   ├── train_visual_rl_4dof.py           # Complete training pipeline
│   └── test_environment.py               # Environment testing script
├── launch/
│   ├── visual_rl_training.launch         # Complete RL training launch
│   └── test_rl_environment.launch        # Test environment setup
├── models/sdf/sphere_goal/
│   └── model.sdf                         # Target sphere model
└── README_VISUAL_RL.md                   # This file
```

## 🚀 Quick Start Guide

### **1. Prerequisites**

Make sure you have the required packages:
```bash
sudo apt install python3-numpy python3-matplotlib python3-torch
sudo apt install ros-noetic-gazebo-ros-control ros-noetic-ros-controllers
```

### **2. Build the Workspace**

```bash
cd ~/rl_model_based/robot_ws
catkin_make
source devel/setup.bash
```

### **3. Test Environment Setup**

First, test that everything works properly:

```bash
# Terminal 1: Launch test environment
roslaunch new_robot_arm_urdf test_rl_environment.launch

# Terminal 2: Run environment tests  
rosrun new_robot_arm_urdf test_environment.py
```

**Expected Results:**
- ✅ Gazebo opens with 4DOF robot and red sphere
- ✅ Robot moves during tests
- ✅ All test components pass
- ✅ "Ready for RL training" message appears

### **4. Run Complete Visual RL Training**

Once tests pass, run the complete training:

```bash
# Terminal 1: Launch visual RL environment
roslaunch new_robot_arm_urdf visual_rl_training.launch

# Terminal 2: Start DDPG training
rosrun new_robot_arm_urdf train_visual_rl_4dof.py
```

**Training Process:**
- 🤖 Robot starts at home position [0,0,0,0]
- 🎯 Red sphere appears at random position in workspace  
- 🧠 DDPG agent learns to move robot arm to reach sphere
- 📊 Training metrics logged every few episodes
- 💾 Models saved automatically during training
- 🎉 Training completes when success rate > 90%

## 📊 Understanding the Training

### **State Space (10 elements):**
- End-effector position (3): [x, y, z] in world coordinates
- Joint positions (4): [Joint_1, Joint_2, Joint_3, Joint_4] in radians  
- Target position (3): [sphere_x, sphere_y, sphere_z] in world coordinates

### **Action Space (4 elements):**
- Joint commands (4): [joint1_pos, joint2_pos, joint3_pos, joint4_pos] 
- Range: Your robot's joint limits (defined in environment)

### **Reward Structure:**
- **Goal Achievement**: +10 when robot reaches sphere (distance < 0.05m)
- **Step Penalty**: -1 per step (encourages faster completion)
- **Episode End**: 200 steps maximum or goal achievement

### **Training Algorithm:**
- **DDPG**: Deep Deterministic Policy Gradient
- **Experience Replay**: Learns from past experiences
- **Target Networks**: Stable learning with soft updates
- **Exploration Noise**: Ornstein-Uhlenbeck process

## 📈 Training Results

Training results are automatically saved to:
```
robot_ws/training_results/ddpg_4dof_YYYYMMDD_HHMMSS/
├── models/          # Saved neural network models
├── plots/           # Training progress plots  
├── logs/            # Training metrics and logs
└── best_model/      # Best performing model
```

### **Monitoring Training:**
- **Console Output**: Real-time episode results and success rates
- **Plot Files**: Automatic generation of training progress plots
- **Model Checkpoints**: Regular saving of learning progress

## 🎮 Key Differences from ROS2 Version

| Aspect | ROS2 Original | ROS Noetic Adaptation |
|--------|---------------|----------------------|
| **Robot** | 6DOF Doosan | 4DOF Your Robot |
| **ROS Version** | ROS2 (Python) | ROS Noetic (ROS1) |
| **Action Client** | `ActionClient` | `actionlib.SimpleActionClient` |
| **Messages** | ROS2 format | ROS1 format |
| **Launch Files** | Python launch | XML launch |
| **State Space** | 12 elements | 10 elements |
| **Action Space** | 6 joints | 4 joints |
| **Joint Names** | `joint1-6` | `Joint_1-4` |
| **Workspace** | Large industrial | Smaller desktop robot |

## 🛠️ Customization Options

### **Modify Training Parameters:**

Edit `train_visual_rl_4dof.py`:
```python
config = {
    'max_episodes': 2000,        # Training episodes
    'batch_size': 128,           # Learning batch size
    'learning_rate_actor': 1e-4, # Actor learning rate
    'noise_scale': 0.1,          # Exploration noise
    'goal_tolerance': 0.05,      # Success distance threshold
}
```

### **Modify Robot Parameters:**

Edit `main_rl_environment_noetic.py`:
```python
# Joint limits for your robot
self.joint_limits_low = np.array([-3.14, -1.57, -2.0, -3.14])
self.joint_limits_high = np.array([3.14, 1.57, 2.0, 3.14])

# Workspace definition
workspace_radius = 0.5    # meters
workspace_max_z = 0.8     # maximum height
```

## 🔧 Troubleshooting

### **Common Issues:**

**1. "Trajectory action server not available"**
```bash
# Check if controllers are loaded
rosservice call /controller_manager/list_controllers

# Restart controllers if needed  
rosservice call /controller_manager/switch_controller "start_controllers: ['arm_controller'] 
stop_controllers: [] strictness: 1"
```

**2. "Environment data not ready"**
```bash
# Check if robot and sphere are spawned
rostopic echo /joint_states
rostopic echo /gazebo/model_states
```

**3. "TF lookup failed"**
```bash
# Check TF tree
rosrun tf2_tools view_frames.py
# Make sure 'world' -> 'link_4_1' transform exists
```

**4. Robot falls or moves erratically**
- Check that your robot has proper mass and inertia values
- Verify joint limits match your robot's capabilities
- Ensure Gazebo physics parameters are stable

### **Debug Mode:**

Run components separately for debugging:
```bash
# Test just the environment
rosrun new_robot_arm_urdf main_rl_environment_noetic.py

# Test just the DDPG algorithm  
rosrun new_robot_arm_urdf ddpg_4dof_noetic.py
```

## 🎯 Expected Training Behavior

### **Early Training (Episodes 1-100):**
- Robot makes random movements
- Rarely reaches target sphere
- Success rate < 5%
- Learning to map state to actions

### **Mid Training (Episodes 100-500):**  
- Robot starts moving toward general target area
- Occasional successful reaches
- Success rate 10-30%
- Developing reaching strategies

### **Late Training (Episodes 500-1000+):**
- Robot consistently reaches target
- Smooth, efficient movements  
- Success rate > 80%
- Converged policy

## 📚 Architecture Comparison

### **Original ROS2 System:**
```
ROS2 Doosan Robot (6DOF) 
  ↓
main_rl_environment.py (ROS2)
  ↓  
DDPG_robot_arm.py (ROS2)
  ↓
Visual training in Gazebo
```

### **Adapted ROS Noetic System:**
```
ROS Noetic 4DOF Robot 
  ↓
main_rl_environment_noetic.py (ROS1)
  ↓
ddpg_4dof_noetic.py (ROS1) 
  ↓
train_visual_rl_4dof.py (Complete Integration)
  ↓
Visual training in Gazebo
```

## 🎉 Success Criteria

Your visual RL training is working correctly when:

✅ **Robot spawns correctly** in Gazebo without falling  
✅ **Controllers respond** to trajectory commands  
✅ **Target sphere** appears and can be moved by environment  
✅ **State data** is properly retrieved (10-element vector)  
✅ **Actions execute** smoothly with proper joint movements  
✅ **Reward calculation** works (distance-based)  
✅ **Training progresses** with improving success rates  
✅ **Models save** automatically during training  

## 📞 Support

If you encounter issues:

1. **Check Prerequisites**: Ensure all ROS packages and Python libraries are installed
2. **Run Tests First**: Always use `test_environment.py` before full training  
3. **Verify Robot Setup**: Make sure your robot works with existing controllers
4. **Check Gazebo**: Ensure robot and sphere spawn without physics issues
5. **Monitor Logs**: Watch ROS logs for specific error messages

---

## 🚀 Ready to Train!

You now have a complete visual RL training system that replicates the ROS2 `robotic_arm_environment` functionality for your 4DOF robot in ROS Noetic!

**Next Steps:**
1. Run the test environment to verify everything works
2. Start visual RL training and watch your robot learn
3. Monitor training progress and adjust parameters as needed
4. Evaluate trained models and deploy for real robot tasks

**Happy Learning!** 🤖✨