#!/usr/bin/env python3
"""
Simple utility to wait for Gazebo to be ready before starting RL training
"""

import rospy
import time
from gazebo_msgs.srv import GetModelState

def wait_for_gazebo(timeout=30.0):
    """Wait for Gazebo to be ready"""
    rospy.loginfo("⏳ Waiting for Gazebo to be ready...")
    
    start_time = time.time()
    
    while (time.time() - start_time) < timeout:
        try:
            rospy.wait_for_service('/gazebo/get_model_state', timeout=1.0)
            rospy.loginfo("✅ Gazebo is ready!")
            return True
        except:
            rospy.loginfo("   Still waiting for Gazebo...")
            time.sleep(1.0)
    
    rospy.logerr("❌ Gazebo failed to start within timeout")
    return False

if __name__ == '__main__':
    rospy.init_node('wait_for_gazebo', anonymous=True)
    wait_for_gazebo()