#!/usr/bin/env python3

"""
Test script for the robot RL environment.
Tests basic functionality like robot state, action execution, and target visualization.
Usage: python3 test_environment.py [number_of_episodes]
"""

import sys
import os

# Add the path to the RL environment
scripts_path = '/home/ducanh/rl_model_based/robot_ws/src/new_robot_arm_urdf/scripts'
sys.path.insert(0, scripts_path)

import rospy
import time
import numpy as np
from main_rl_environment_noetic import RLEnvironmentNoetic

def test_environment(num_episodes=3):
    """Test the RL environment functionality with specified number of episodes."""
    print(f"Testing RL Environment with {num_episodes} episodes...")
    
    try:
        # Initialize ROS node
        rospy.init_node('test_environment', anonymous=True)
        print("✓ ROS node initialized")
        
        # Create environment
        env = RLEnvironmentNoetic()
        print("✓ Environment created")
        
        # Wait for initialization
        print("Waiting for environment to initialize...")
        time.sleep(3)
        
        # Test multiple episodes
        for episode in range(num_episodes):
            print(f"\n{'='*50}")
            print(f"🎯 EPISODE {episode + 1}/{num_episodes}")
            print(f"{'='*50}")
            
            # Reset environment
            print("Resetting environment...")
            reset_success = env.reset_environment()
            print(f"✓ Environment reset successful: {reset_success}")
            
            # Get initial observation
            observation = env.get_state()
            if observation is not None:
                print(f"Initial observation shape: {np.array(observation).shape}")
                print(f"Initial observation: {np.array(observation)[:10]}...")  # Show first 10 values
            else:
                print("✗ Failed to get initial observation")
            
            # Test some random actions in this episode
            print(f"\nTesting 3 actions in episode {episode + 1}...")
            for i in range(3):
                print(f"\n--- Action {i+1} ---")
                
                # Generate random action using environment method
                action = env.generate_random_action()
                print(f"Action: {action}")
                
                # Execute action
                action_success = env.execute_action(action)
                print(f"Action execution successful: {action_success}")
                
                # Get new observation
                observation = env.get_state()
                if observation is not None:
                    print(f"New observation: {np.array(observation)[:10]}...")  # Show first 10 values
                
                # Calculate reward
                reward, done = env.calculate_reward()
                print(f"Reward: {reward:.4f}")
                print(f"Done: {done}")
                
                # Get distance to goal
                distance = env.get_distance_to_goal()
                print(f"Distance to goal: {distance:.4f}")
                
                # Wait a bit between actions
                time.sleep(1)
                
                if done:
                    print(f"🎉 Episode {episode + 1} completed!")
                    break
            
            # Wait 2 seconds between episodes
            print(f"⏳ Waiting 2 seconds before next episode...")
            time.sleep(2)
        
        print(f"\n✓ All {num_episodes} episodes completed successfully!")
        
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == '__main__':
    # Get number of episodes from command line argument
    num_episodes = 3  # default
    if len(sys.argv) > 1:
        try:
            num_episodes = int(sys.argv[1])
            if num_episodes <= 0:
                print("Number of episodes must be positive!")
                sys.exit(1)
        except ValueError:
            print("Please provide a valid number of episodes!")
            print("Usage: python3 test_environment.py [number_of_episodes]")
            sys.exit(1)
    
    print(f"Starting test with {num_episodes} episodes...")
    success = test_environment(num_episodes)
    sys.exit(0 if success else 1)