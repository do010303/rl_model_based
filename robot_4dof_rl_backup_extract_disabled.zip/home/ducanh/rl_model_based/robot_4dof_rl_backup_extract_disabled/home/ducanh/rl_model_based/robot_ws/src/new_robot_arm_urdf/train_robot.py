#!/usr/bin/env python3

"""
Simple Training Script for 4DOF Robot Drawing Task
Allows configurable number of episodes and episode parameters.
"""

import sys
import os
import argparse

# Add the path to the RL environment
sys.path.append('/home/ducanh/rl_model_based/robot_ws/src/new_robot_arm_urdf/scripts')

import rospy
import time
import numpy as np
from main_rl_environment_noetic import RLEnvironmentNoetic

def train_robot(num_episodes=10, max_steps_per_episode=200, goal_tolerance=0.02):
    """
    Train the robot for drawing tasks
    
    Args:
        num_episodes: Number of training episodes
        max_steps_per_episode: Maximum steps per episode  
        goal_tolerance: Distance threshold for goal achievement
    """
    print(f"🚀 Starting Robot Drawing Training")
    print(f"📊 Episodes: {num_episodes}")
    print(f"📏 Max steps per episode: {max_steps_per_episode}")
    print(f"🎯 Goal tolerance: {goal_tolerance}m")
    print("=" * 50)
    
    try:
        # Initialize ROS node
        rospy.init_node('robot_drawing_trainer', anonymous=True)
        print("✓ ROS node initialized")
        
        # Create environment with configurable parameters
        env = RLEnvironmentNoetic(
            max_episode_steps=max_steps_per_episode,
            goal_tolerance=goal_tolerance
        )
        print("✓ Environment created")
        
        # Wait for initialization
        print("Waiting for environment to initialize...")
        time.sleep(3)
        
        # Training statistics
        successful_episodes = 0
        total_rewards = []
        episode_lengths = []
        
        # Training loop
        for episode in range(num_episodes):
            print(f"\n🎮 EPISODE {episode + 1}/{num_episodes}")
            print("-" * 30)
            
            # Reset environment
            reset_success = env.reset_environment()
            if not reset_success:
                print(f"❌ Failed to reset environment for episode {episode + 1}")
                continue
                
            observation = env.get_state()
            episode_reward = 0
            step_count = 0
            episode_success = False
            
            # Episode loop
            while step_count < max_steps_per_episode:
                # Generate random action (replace with your RL algorithm)
                action = env.generate_random_action()
                
                # Execute action
                action_success = env.execute_action(action)
                
                # Get new state and reward
                new_observation = env.get_state()
                reward, done = env.calculate_reward()
                
                episode_reward += reward
                step_count += 1
                
                # Print step info every 10 steps
                if step_count % 10 == 0:
                    distance = env.get_distance_to_goal()
                    print(f"   Step {step_count}: distance={distance:.3f}m, reward={reward:.2f}")
                
                # Check if episode is complete
                if done:
                    if reward > 0:  # Goal achieved
                        episode_success = True
                        successful_episodes += 1
                        print(f"🏆 GOAL ACHIEVED in {step_count} steps!")
                    else:
                        print(f"⏰ Episode completed (time limit)")
                    break
                
                observation = new_observation
                time.sleep(0.1)  # Small delay for visualization
            
            # Episode summary
            total_rewards.append(episode_reward)
            episode_lengths.append(step_count)
            
            print(f"Episode {episode + 1} Summary:")
            print(f"  ✅ Success: {episode_success}")
            print(f"  📏 Steps: {step_count}")
            print(f"  🎁 Reward: {episode_reward:.2f}")
            print(f"  🎯 Success Rate: {successful_episodes}/{episode + 1} ({100*successful_episodes/(episode+1):.1f}%)")
        
        # Final training summary
        print("\n" + "=" * 50)
        print("🏁 TRAINING COMPLETED!")
        print("=" * 50)
        print(f"📊 Total Episodes: {num_episodes}")
        print(f"🏆 Successful Episodes: {successful_episodes}")
        print(f"📈 Success Rate: {100*successful_episodes/num_episodes:.1f}%")
        print(f"🎁 Average Reward: {np.mean(total_rewards):.2f}")
        print(f"📏 Average Episode Length: {np.mean(episode_lengths):.1f} steps")
        
        return True
        
    except Exception as e:
        print(f"❌ Training failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    parser = argparse.ArgumentParser(description='Train 4DOF Robot for Drawing Tasks')
    parser.add_argument('--episodes', type=int, default=10, 
                        help='Number of training episodes (default: 10)')
    parser.add_argument('--max-steps', type=int, default=200,
                        help='Maximum steps per episode (default: 200)')
    parser.add_argument('--goal-tolerance', type=float, default=0.02,
                        help='Goal distance tolerance in meters (default: 0.02)')
    
    args = parser.parse_args()
    
    success = train_robot(
        num_episodes=args.episodes,
        max_steps_per_episode=args.max_steps,
        goal_tolerance=args.goal_tolerance
    )
    
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()